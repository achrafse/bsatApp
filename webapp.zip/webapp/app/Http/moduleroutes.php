<?php
        Route::controller('agences', 'AgencesController');
                    Route::controller('agents', 'AgentsController');
                    Route::controller('traducteurs', 'TraducteursController');
                    Route::controller('centreservice', 'CentreserviceController');
                    Route::controller('chambredecommerce', 'ChambredecommerceController');
                    Route::controller('administrationmaroc', 'AdministrationmarocController');
                    ?>