<?php 
Route::get('service', 'HomeController@index');
Route::get('about-us', 'HomeController@index');
Route::get('contact-us', 'HomeController@index');
Route::get('privacy', 'HomeController@index');
Route::get('toc', 'HomeController@index');
Route::get('printing-and-typesetting-industry', 'HomeController@index');
Route::get('new-sximo-5.1.6-sept-2016', 'HomeController@index');
Route::get('-remaining-essentially-unchanged', 'HomeController@index');
?>