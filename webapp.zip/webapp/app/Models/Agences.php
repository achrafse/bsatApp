<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class agences extends Sximo  {
	
	protected $table = 'tb_agences';
	protected $primaryKey = 'matricule';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return "  SELECT tb_agences.* FROM tb_agences  ";
	}	

	public static function queryWhere(  ){
		
		return "  WHERE tb_agences.matricule IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
