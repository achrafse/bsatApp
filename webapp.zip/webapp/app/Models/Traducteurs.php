<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class traducteurs extends Sximo  {
	
	protected $table = 'tb_traducteurs';
	protected $primaryKey = 'matricule';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return "  SELECT tb_traducteurs.* FROM tb_traducteurs  ";
	}	

	public static function queryWhere(  ){
		
		return "  WHERE tb_traducteurs.matricule IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
