<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;

class agents extends Sximo  {
	
	protected $table = 'agents';
	protected $primaryKey = 'matricule';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		return "  SELECT agents.* FROM agents  ";
	}	

	public static function queryWhere(  ){
		
		return "  WHERE agents.matricule IS NOT NULL ";
	}
	
	public static function queryGroup(){
		return "  ";
	}
	

}
