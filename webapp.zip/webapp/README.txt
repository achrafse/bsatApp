Earth's Moon
