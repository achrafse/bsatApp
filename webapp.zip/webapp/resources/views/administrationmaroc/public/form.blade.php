

		 {!! Form::open(array('url'=>'administrationmaroc/savepublic', 'class'=>'form-horizontal','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}

	@if(Session::has('messagetext'))
	  
		   {!! Session::get('messagetext') !!}
	   
	@endif
	<ul class="parsley-error-list">
		@foreach($errors->all() as $error)
			<li>{{ $error }}</li>
		@endforeach
	</ul>		


<div class="col-md-12">
						<fieldset><legend> Administration Marocainnes</legend>
									
									  <div class="form-group  " >
										<label for="Id" class=" control-label col-md-4 text-left"> Id </label>
										<div class="col-md-7">
										  <input  type='text' name='id' id='id' value='{{ $row['id'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="NomAdministration" class=" control-label col-md-4 text-left"> NomAdministration </label>
										<div class="col-md-7">
										  <input  type='text' name='nomAdministration' id='nomAdministration' value='{{ $row['nomAdministration'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="ClassementAdministration" class=" control-label col-md-4 text-left"> ClassementAdministration </label>
										<div class="col-md-7">
										  <input  type='text' name='classementAdministration' id='classementAdministration' value='{{ $row['classementAdministration'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="CategorieAdministration" class=" control-label col-md-4 text-left"> CategorieAdministration </label>
										<div class="col-md-7">
										  <input  type='text' name='categorieAdministration' id='categorieAdministration' value='{{ $row['categorieAdministration'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="VilleAdministration" class=" control-label col-md-4 text-left"> VilleAdministration </label>
										<div class="col-md-7">
										  <input  type='text' name='villeAdministration' id='villeAdministration' value='{{ $row['villeAdministration'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="EmailAdministration" class=" control-label col-md-4 text-left"> EmailAdministration </label>
										<div class="col-md-7">
										  <input  type='text' name='emailAdministration' id='emailAdministration' value='{{ $row['emailAdministration'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="TelephoneAdministration" class=" control-label col-md-4 text-left"> TelephoneAdministration </label>
										<div class="col-md-7">
										  <input  type='text' name='telephoneAdministration' id='telephoneAdministration' value='{{ $row['telephoneAdministration'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="SiteWeb" class=" control-label col-md-4 text-left"> SiteWeb </label>
										<div class="col-md-7">
										  <input  type='text' name='siteWeb' id='siteWeb' value='{{ $row['siteWeb'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> </fieldset>
			</div>
			
			

			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-info btn-sm" ><i class="fa  fa-check-circle"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-primary btn-sm" ><i class="fa  fa-save "></i> {{ Lang::get('core.sb_save') }}</button>
				  </div>	  
			
		</div> 
		 
		 {!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		 

		$('.removeCurrentFiles').on('click',function(){
			var removeUrl = $(this).attr('href');
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
