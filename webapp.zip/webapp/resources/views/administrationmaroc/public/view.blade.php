<div class="m-t" style="padding-top:25px;">	
    <div class="row m-b-lg animated fadeInDown delayp1 text-center">
        <h3> {{ $pageTitle }} <small> {{ $pageNote }} </small></h3>
        <hr />       
    </div>
</div>
<div class="m-t">
	<div class="table-responsive" > 	

		<table class="table table-striped table-bordered" >
			<tbody>	
		
			
					<tr>
						<td width='30%' class='label-view text-right'>Id</td>
						<td>{{ $row->id}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>NomAdministration</td>
						<td>{{ $row->nomAdministration}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>ClassementAdministration</td>
						<td>{{ $row->classementAdministration}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>CategorieAdministration</td>
						<td>{{ $row->categorieAdministration}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>VilleAdministration</td>
						<td>{{ $row->villeAdministration}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>EmailAdministration</td>
						<td>{{ $row->emailAdministration}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>TelephoneAdministration</td>
						<td>{{ $row->telephoneAdministration}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>SiteWeb</td>
						<td>{{ $row->siteWeb}} </td>
						
					</tr>
						
					<tr>
						<td width='30%' class='label-view text-right'></td>
						<td> <a href="javascript:history.go(-1)" class="btn btn-primary"> Back To Grid <a> </td>
						
					</tr>					
				
			</tbody>	
		</table>   

	 
	
	</div>
</div>	