<div class="m-t" style="padding-top:25px;">	
    <div class="row m-b-lg animated fadeInDown delayp1 text-center">
        <h3> {{ $pageTitle }} <small> {{ $pageNote }} </small></h3>
        <hr />       
    </div>
</div>
<div class="m-t">
	<div class="table-responsive" > 	

		<table class="table table-striped table-bordered" >
			<tbody>	
		
			
					<tr>
						<td width='30%' class='label-view text-right'>NomD'agence</td>
						<td>{{ $row->nomAgence}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>AdresseD'agence</td>
						<td>{{ $row->adresseAgence}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>TelephoneD'agence</td>
						<td>{{ $row->telephoneAgence}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>EmailD'agence</td>
						<td><a href="mailto{{$row->emailAgence}}">{{ $row->emailAgence}} </a> </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>ChefD'agence</td>
						<td>{{ $row->chefAgence}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>AgentNiveau1</td>
						<td>{{ $row->agentNiveau1}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>AgentNiveau2</td>
						<td>{{ $row->agentNiveau2}} </td>
						
					</tr>
						
					<tr>
						<td width='30%' class='label-view text-right'></td>
						<td> <a href="javascript:history.go(-1)" class="btn btn-primary"> Back To Grid <a> </td>
						
					</tr>					
				
			</tbody>	
		</table>   

	 
	
	</div>
</div>	