@extends('layouts.app')

@section('content')

  <div class="page-content row">
    <!-- Page header -->

 
 	<div class="page-content-wrapper m-t">


<div class="sbox">
	<div class="sbox-title"> 
		<div class="sbox-tools pull-left" >
			<a href="{{ url($pageModule.'?return='.$return) }}" class="tips btn btn-xs btn-default"  title="{{ Lang::get('core.btn_back') }}" ><i class="fa  fa-arrow-left"></i></a> 
		</div>
		<div class="sbox-tools " >
			@if(Session::get('gid') ==1)
				<a href="{{ URL::to('sximo/module/config/'.$pageModule) }}" class="tips btn btn-xs btn-default" title=" {{ Lang::get('core.btn_config') }}" ><i class="fa  fa-ellipsis-v"></i></a>
			@endif 			
		</div> 

	</div>
	<div class="sbox-content"> 	

		<ul class="parsley-error-list">
			@foreach($errors->all() as $error)
				<li>{{ $error }}</li>
			@endforeach
		</ul>	

		 {!! Form::open(array('url'=>'agences/save?return='.$return, 'class'=>'form-horizontal','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}
<div class="col-md-12">
						<fieldset><legend> Agences</legend>
									
									  <div class="form-group  " >
										<label for="NomD'agence" class=" control-label col-md-4 text-left"> NomD'agence <span class="asterix"> * </span></label>
										<div class="col-md-7">
										  <input  type='text' name='nomAgence' id='nomAgence' value='{{ $row['nomAgence'] }}' 
						required     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="AdresseD'gence" class=" control-label col-md-4 text-left"> AdresseD'gence </label>
										<div class="col-md-7">
										  <input  type='text' name='adresseAgence' id='adresseAgence' value='{{ $row['adresseAgence'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="TelephoneD'agence" class=" control-label col-md-4 text-left"> TelephoneD'agence <span class="asterix"> * </span></label>
										<div class="col-md-7">
										  <input  type='text' name='telephoneAgence' id='telephoneAgence' value='{{ $row['telephoneAgence'] }}' 
						required     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="EmailD'agence" class=" control-label col-md-4 text-left"> EmailD'agence <span class="asterix"> * </span></label>
										<div class="col-md-7">
										  <input  type='text' name='emailAgence' id='emailAgence' value='{{ $row['emailAgence'] }}' 
						required     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="ChefD'agence" class=" control-label col-md-4 text-left"> ChefD'agence </label>
										<div class="col-md-7">
										  <input  type='text' name='chefAgence' id='chefAgence' value='{{ $row['chefAgence'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="AgentNiveau1" class=" control-label col-md-4 text-left"> AgentNiveau1 </label>
										<div class="col-md-7">
										  <input  type='text' name='agentNiveau1' id='agentNiveau1' value='{{ $row['agentNiveau1'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="AgentNiveau2" class=" control-label col-md-4 text-left"> AgentNiveau2 </label>
										<div class="col-md-7">
										  <input  type='text' name='agentNiveau2' id='agentNiveau2' value='{{ $row['agentNiveau2'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> </fieldset>
			</div>
			
			

		
			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-info btn-sm" ><i class="icon-checkmark-circle2"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-primary btn-sm" ><i class="icon-bubble-check"></i> {{ Lang::get('core.sb_save') }}</button>
					<button type="button" onclick="location.href='{{ URL::to('agences?return='.$return) }}' " class="btn btn-warning btn-sm "><i class="icon-cancel-circle2 "></i>  {{ Lang::get('core.sb_cancel') }} </button>
					</div>	  
			
				  </div> 
		 
		 {!! Form::close() !!}
	</div>
</div>		 
</div>	
</div>			 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		 

		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("agences/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
@stop