

		 {!! Form::open(array('url'=>'centreservice/savepublic', 'class'=>'form-horizontal','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}

	@if(Session::has('messagetext'))
	  
		   {!! Session::get('messagetext') !!}
	   
	@endif
	<ul class="parsley-error-list">
		@foreach($errors->all() as $error)
			<li>{{ $error }}</li>
		@endforeach
	</ul>		


<div class="col-md-12">
						<fieldset><legend> Centres De Sérvices</legend>
									
									  <div class="form-group  " >
										<label for="NomDuCentre" class=" control-label col-md-4 text-left"> NomDuCentre <span class="asterix"> * </span></label>
										<div class="col-md-7">
										  <input  type='text' name='NomDuCentre' id='NomDuCentre' value='{{ $row['NomDuCentre'] }}' 
						required     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="CategorieDuCentre" class=" control-label col-md-4 text-left"> CategorieDuCentre </label>
										<div class="col-md-7">
										  <input  type='text' name='categorieDuCentre' id='categorieDuCentre' value='{{ $row['categorieDuCentre'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="PaysDuCentre" class=" control-label col-md-4 text-left"> PaysDuCentre <span class="asterix"> * </span></label>
										<div class="col-md-7">
										  <input  type='text' name='paysDuCentre' id='paysDuCentre' value='{{ $row['paysDuCentre'] }}' 
						required     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="VilleDuCentre" class=" control-label col-md-4 text-left"> VilleDuCentre <span class="asterix"> * </span></label>
										<div class="col-md-7">
										  <input  type='text' name='villeDuCentre' id='villeDuCentre' value='{{ $row['villeDuCentre'] }}' 
						required     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="EmailDuCentre" class=" control-label col-md-4 text-left"> EmailDuCentre <span class="asterix"> * </span></label>
										<div class="col-md-7">
										  <input  type='text' name='emailDuCentre' id='emailDuCentre' value='{{ $row['emailDuCentre'] }}' 
						required     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="TelephoneDuCentre" class=" control-label col-md-4 text-left"> TelephoneDuCentre <span class="asterix"> * </span></label>
										<div class="col-md-7">
										  <input  type='text' name='telephoneDuCentre' id='telephoneDuCentre' value='{{ $row['telephoneDuCentre'] }}' 
						required     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="SiteWeb" class=" control-label col-md-4 text-left"> SiteWeb </label>
										<div class="col-md-7">
										  <input  type='text' name='siteWeb' id='siteWeb' value='{{ $row['siteWeb'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> </fieldset>
			</div>
			
			

			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-info btn-sm" ><i class="fa  fa-check-circle"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-primary btn-sm" ><i class="fa  fa-save "></i> {{ Lang::get('core.sb_save') }}</button>
				  </div>	  
			
		</div> 
		 
		 {!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		 

		$('.removeCurrentFiles').on('click',function(){
			var removeUrl = $(this).attr('href');
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
