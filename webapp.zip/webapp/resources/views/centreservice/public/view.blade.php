<div class="m-t" style="padding-top:25px;">	
    <div class="row m-b-lg animated fadeInDown delayp1 text-center">
        <h3> {{ $pageTitle }} <small> {{ $pageNote }} </small></h3>
        <hr />       
    </div>
</div>
<div class="m-t">
	<div class="table-responsive" > 	

		<table class="table table-striped table-bordered" >
			<tbody>	
		
			
					<tr>
						<td width='30%' class='label-view text-right'>NomDuCentre</td>
						<td>{{ $row->NomDuCentre}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>CategorieDuCentre</td>
						<td>{{ $row->categorieDuCentre}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>PaysDuCentre</td>
						<td>{{ $row->paysDuCentre}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>VilleDuCentre</td>
						<td>{{ $row->villeDuCentre}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>EmailDuCentre</td>
						<td><a href="mailto:{{$row->emailDuCentre}}">{{ $row->emailDuCentre}} </a> </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>TelephoneDuCentre</td>
						<td>{{ $row->telephoneDuCentre}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>SiteWeb</td>
						<td><a href="">{{ $row->siteWeb}} </a> </td>
						
					</tr>
						
					<tr>
						<td width='30%' class='label-view text-right'></td>
						<td> <a href="javascript:history.go(-1)" class="btn btn-primary"> Back To Grid <a> </td>
						
					</tr>					
				
			</tbody>	
		</table>   

	 
	
	</div>
</div>	