<div class="m-t" style="padding-top:25px;">	
    <div class="row m-b-lg animated fadeInDown delayp1 text-center">
        <h3> {{ $pageTitle }} <small> {{ $pageNote }} </small></h3>
        <hr />       
    </div>
</div>
<div class="m-t">
	<div class="table-responsive" > 	

		<table class="table table-striped table-bordered" >
			<tbody>	
		
			
					<tr>
						<td width='30%' class='label-view text-right'>Nom&Prenom</td>
						<td>{{ $row->nomPrenomAgent}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>FonctionAgent</td>
						<td>{{ $row->fonctionAgent}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>EmailAgent</td>
						<td><a href="mailto{{$row->emailAgent}}">{{ $row->emailAgent}} </a> </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>TelephoneAgent</td>
						<td>{{ $row->telephoneAgent}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>Agence</td>
						<td>{{ $row->agence}} </td>
						
					</tr>
						
					<tr>
						<td width='30%' class='label-view text-right'></td>
						<td> <a href="javascript:history.go(-1)" class="btn btn-primary"> Back To Grid <a> </td>
						
					</tr>					
				
			</tbody>	
		</table>   

	 
	
	</div>
</div>	