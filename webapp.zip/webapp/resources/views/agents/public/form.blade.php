

		 {!! Form::open(array('url'=>'agents/savepublic', 'class'=>'form-horizontal','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}

	@if(Session::has('messagetext'))
	  
		   {!! Session::get('messagetext') !!}
	   
	@endif
	<ul class="parsley-error-list">
		@foreach($errors->all() as $error)
			<li>{{ $error }}</li>
		@endforeach
	</ul>		


<div class="col-md-12">
						<fieldset><legend> Agents</legend>
									
									  <div class="form-group  " >
										<label for="NomPrenomAgent" class=" control-label col-md-4 text-left"> NomPrenomAgent <span class="asterix"> * </span></label>
										<div class="col-md-7">
										  <input  type='text' name='nomPrenomAgent' id='nomPrenomAgent' value='{{ $row['nomPrenomAgent'] }}' 
						required     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="FonctionAgent" class=" control-label col-md-4 text-left"> FonctionAgent <span class="asterix"> * </span></label>
										<div class="col-md-7">
										  
					<?php $fonctionAgent = explode(',',$row['fonctionAgent']);
					$fonctionAgent_opt = array( 'Chef Agence' => 'Chef Agence' ,  'Agent Niveau 1' => 'Agent Niveau 1' ,  'Agent Niveau 2' => 'Agent Niveau 2' , ); ?>
					<select name='fonctionAgent' rows='5' required  class='select2 ' id='fonctionAgent'  > 
						<?php 
						foreach($fonctionAgent_opt as $key=>$val)
						{
							echo "<option  value ='$key' ".($row['fonctionAgent'] == $key ? " selected='selected' " : '' ).">$val</option>"; 						
						}						
						?></select> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="EmailAgent" class=" control-label col-md-4 text-left"> EmailAgent <span class="asterix"> * </span></label>
										<div class="col-md-7">
										  <input  type='text' name='emailAgent' id='emailAgent' value='{{ $row['emailAgent'] }}' 
						required     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="TelephoneAgent" class=" control-label col-md-4 text-left"> TelephoneAgent <span class="asterix"> * </span></label>
										<div class="col-md-7">
										  <input  type='text' name='telephoneAgent' id='telephoneAgent' value='{{ $row['telephoneAgent'] }}' 
						required     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="Agence" class=" control-label col-md-4 text-left"> Agence </label>
										<div class="col-md-7">
										  <select name='agence' rows='5' id='agence' class='select2 '   ></select> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> </fieldset>
			</div>
			
			

			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-info btn-sm" ><i class="fa  fa-check-circle"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-primary btn-sm" ><i class="fa  fa-save "></i> {{ Lang::get('core.sb_save') }}</button>
				  </div>	  
			
		</div> 
		 
		 {!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		$("#agence").jCombo("{!! url('agents/comboselect?filter=tb_agences:nomAgence:nomAgence') !!}",
		{  selected_value : '{{ $row["agence"] }}' });
		 

		$('.removeCurrentFiles').on('click',function(){
			var removeUrl = $(this).attr('href');
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
