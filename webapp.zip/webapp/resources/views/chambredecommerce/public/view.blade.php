<div class="m-t" style="padding-top:25px;">	
    <div class="row m-b-lg animated fadeInDown delayp1 text-center">
        <h3> {{ $pageTitle }} <small> {{ $pageNote }} </small></h3>
        <hr />       
    </div>
</div>
<div class="m-t">
	<div class="table-responsive" > 	

		<table class="table table-striped table-bordered" >
			<tbody>	
		
			
					<tr>
						<td width='30%' class='label-view text-right'>NomDeChambre</td>
						<td>{{ $row->NomDeChambre}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>CategorieDeChambre</td>
						<td>{{ $row->categorieDeChambre}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>PaysDeChambre</td>
						<td>{{ $row->paysDeChambre}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>VilleDeChambre</td>
						<td>{{ $row->villeDeChambre}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>EmailDeChambre</td>
						<td><a href="mailto:{{$row->emailDeChambre}}">{{ $row->emailDeChambre}} </a> </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>TelephoneDeChambre</td>
						<td>{{ $row->telephoneDeChambre}} </td>
						
					</tr>
				
					<tr>
						<td width='30%' class='label-view text-right'>SiteWeb</td>
						<td><a href="">{{ $row->siteWeb}} </a> </td>
						
					</tr>
						
					<tr>
						<td width='30%' class='label-view text-right'></td>
						<td> <a href="javascript:history.go(-1)" class="btn btn-primary"> Back To Grid <a> </td>
						
					</tr>					
				
			</tbody>	
		</table>   

	 
	
	</div>
</div>	