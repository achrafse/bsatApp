@extends('layouts.app')

@section('content')

  <div class="page-content row">
    <!-- Page header -->

 
 	<div class="page-content-wrapper m-t">


<div class="sbox">
	<div class="sbox-title"> 
		<div class="sbox-tools pull-left" >
			<a href="{{ url($pageModule.'?return='.$return) }}" class="tips btn btn-xs btn-default"  title="{{ Lang::get('core.btn_back') }}" ><i class="fa  fa-arrow-left"></i></a> 
		</div>
		<div class="sbox-tools " >
			@if(Session::get('gid') ==1)
				<a href="{{ URL::to('sximo/module/config/'.$pageModule) }}" class="tips btn btn-xs btn-default" title=" {{ Lang::get('core.btn_config') }}" ><i class="fa  fa-ellipsis-v"></i></a>
			@endif 			
		</div> 

	</div>
	<div class="sbox-content"> 	

		<ul class="parsley-error-list">
			@foreach($errors->all() as $error)
				<li>{{ $error }}</li>
			@endforeach
		</ul>	

		 {!! Form::open(array('url'=>'chambredecommerce/save?return='.$return, 'class'=>'form-horizontal','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}
<div class="col-md-12">
						<fieldset><legend> Chambre De Commerce</legend>
									
									  <div class="form-group  " >
										<label for="NomDeChambre" class=" control-label col-md-4 text-left"> NomDeChambre </label>
										<div class="col-md-7">
										  <input  type='text' name='NomDeChambre' id='NomDeChambre' value='{{ $row['NomDeChambre'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="CategorieDeChambre" class=" control-label col-md-4 text-left"> CategorieDeChambre </label>
										<div class="col-md-7">
										  <input  type='text' name='categorieDeChambre' id='categorieDeChambre' value='{{ $row['categorieDeChambre'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="PaysDeChambre" class=" control-label col-md-4 text-left"> PaysDeChambre </label>
										<div class="col-md-7">
										  <input  type='text' name='paysDeChambre' id='paysDeChambre' value='{{ $row['paysDeChambre'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="VilleDeChambre" class=" control-label col-md-4 text-left"> VilleDeChambre </label>
										<div class="col-md-7">
										  <input  type='text' name='villeDeChambre' id='villeDeChambre' value='{{ $row['villeDeChambre'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="EmailDeChambre" class=" control-label col-md-4 text-left"> EmailDeChambre </label>
										<div class="col-md-7">
										  <input  type='text' name='emailDeChambre' id='emailDeChambre' value='{{ $row['emailDeChambre'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="TelephoneDeChambre" class=" control-label col-md-4 text-left"> TelephoneDeChambre </label>
										<div class="col-md-7">
										  <input  type='text' name='telephoneDeChambre' id='telephoneDeChambre' value='{{ $row['telephoneDeChambre'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> 					
									  <div class="form-group  " >
										<label for="SiteWeb" class=" control-label col-md-4 text-left"> SiteWeb </label>
										<div class="col-md-7">
										  <input  type='text' name='siteWeb' id='siteWeb' value='{{ $row['siteWeb'] }}' 
						     class='form-control ' /> 
										 </div> 
										 <div class="col-md-1">
										 	
										 </div>
									  </div> </fieldset>
			</div>
			
			

		
			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-info btn-sm" ><i class="icon-checkmark-circle2"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-primary btn-sm" ><i class="icon-bubble-check"></i> {{ Lang::get('core.sb_save') }}</button>
					<button type="button" onclick="location.href='{{ URL::to('chambredecommerce?return='.$return) }}' " class="btn btn-warning btn-sm "><i class="icon-cancel-circle2 "></i>  {{ Lang::get('core.sb_cancel') }} </button>
					</div>	  
			
				  </div> 
		 
		 {!! Form::close() !!}
	</div>
</div>		 
</div>	
</div>			 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		 

		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("chambredecommerce/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
@stop