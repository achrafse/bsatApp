<?php

return array(
// General 
	"norecord" => "Aucun enregistrement trouvé",
	"create" => "Créer nouveau",

	// General , Login Info & Signup
	"home" => "Accueil",
	"group" => "Groupe",
	"username" => "Nom d’utilisateur",
	"email" => "Adresse de courriel",
	"password" => "Mot de passe",
	"repassword" => "Confirmer mot de passe",
	"forgotpassword" => "Mot de passe oublié",
	"newpassword" => "Nouveau mot de passe",
	"conewpassword" => "Confirmer mot de passe",
	"notepassword" => "Laissez vide si vous ne souhaitez pas changer de mot de passe actuel", // updated apidevlab	
	"submit" => "Envoyer",
	"signin" => "Se Connecter",
	"signup" => "inscription ",
	"subscribe" => "S’abonner",
	"language" => "Langue",
	"subscription" => "Abonnement",
	"firstname" => "Prénom",
	"lastname" => "Nom ",
	"lastlogin"	=> "Dernière connexion",
	"personalinfo"	=> "Informations personnelles",
	"changepassword"	=> "Changer mot de passe",
	"registernew" => "Créer nouveau compte ",
	"backtosite" => " Retour au Site ",
	"planexpiration" => "Plan d'expiration",
	'invitationmail' => 'Invitation Mail',
	
/* grid , pagination */
	"grid_displaying" 	=> "Affichage",
	"grid_to" 			=> "à",
	"grid_of" 			=> "de",
	"grid_show" 			=> "voir",
	"grid_sort" 			=> "trier",
	"grid_order" 			=> "ordre",	
	"grid_page" 			=> "Page",	
		

/* Menu navigation here */
	"m_controlpanel"	=> "Panneau de configuration",
	"m_dashboard" 		=> "Tableau De Bord",
	"m_setting" 		=> "Paramètres", // updated apidevlab
	"m_usersgroups" 	=> "Utilisateurs & Groupes",
	"m_users" 			=> "Utilisateurs",
	"m_groups" 			=> "Groupes",
	"m_pagecms" 		=> "Page CMS",
	"m_menu" 			=> " Gestion De Menu",
	"m_logs" 			=> "Activité Logs",
	"m_codebuilder" 	=> "Code Generateur",
	"m_blastemail" 		=> "Blast Email",
	"m_myaccount" 		=> "Mon Compte ",
	"m_logout" 			=> "Dèconnexion",
	"m_profile" 		=> "Profil",
	"m_manual" 		=> "Guide Manuel ",

/* Setting page translation */	

	"t_generalsetting"		=> "Paramètres généraux", //updated apidevlab
	"t_generalsettingsmall"	=> "Gérer les paramètres Configuration", // updated apidevlab
	"t_blastemail"			=> "Blast Email", // updated apidevlab
	"t_blastemailsmall"		=> "Envoyer Bulk Email",
	"t_emailtemplate"		=> "Modèles d’e-mail",
	"t_emailtemplatesmall"	=> "Gérer les modèles d’E-mail", // updated apidevlab
	"t_loginsecurity"		=> "Login & Securité", // updated apidevlab
	"t_loginsecuritysmall"	=> "Gérer Logins & Security",	// updated apidevlab	
	"t_socialmedia"			=> "Social Media connexion", // updated apidevlab
	"t_lfb"					=> "connexion via Facebook", // updated apidevlab
	"t_lgoogle"				=> "connexion via Google", // updated apidevlab
	"t_ltwit"				=> "connexion via Twitter", // updated apidevlab
	"tab_siteinfo"			=> "Paramètres généraux", // Site Info updated apidevlab
	"tab_loginsecurity"		=> "Login & Securité",
	"tab_email"				=> "Modèles d’e-mail", // updated apidevlab
	"tab_translation"			=> "Translation", 
	"fr_appname"			=> "Nom de l’application ",
	"fr_appdesc"			=> "Desc d'application",
	"fr_comname"			=> "Nom de la société ",
	"fr_emailsys"			=> "Email Systeme",
	"fr_emailmessage"		=> "Email Message ",
	"fr_enable"				=> "Enable",
	"fr_multilanguage"			=> "Muliti langage",
	"fr_mainlanguage"			=> "Langue Principale",
	"fr_fronttemplate"			=> "Frontend Template",
	"fr_appmode"			=> "Application Mode",
	"fr_appid"				=> "APP ID",
	"fr_secret"				=> "NUMÉRO SECRET",
	"fr_registrationdefault"		=> "Enregistrement de groupe par défaut ",
	"fr_registrationsetting"	=> "Réglage de l’enregistrement",
	"fr_registration"		=> "Enregistrement",
	"fr_allowregistration"		=> "Permettre l’enregistrement",
	"fr_allowfrontend"			=> "Permettre Frontend",
	"fr_registrationauto"		=> "activation Automatique ",
	"fr_registrationmanual"		=> "activation Manuelle",
	"fr_registrationemail"		=> "Email avec lien d'activation ",	
	"fr_emailsubject"				=> "Sujet",
	"fr_emailsendto"				=> "Envoyer à",
	"fr_emailmessage"				=> "Email Message",
	"fr_emailtag"					=> "Vous pouvez utiliser",
	
	
/* submit */
	"sb_savechanges"			=> "Enregistrer les modifications",
	"sb_send"					=> "Envoyer",
	"sb_save"					=> "Enregistrer",
	"sb_apply"					=> "Appliquer les changements",
	"sb_submit"					=> "Envoyer",
	"sb_cancel"					=> "Annuler",	
	
/* button */
	"btn_back"						=> "Précédent",	
	"btn_action"					=> "Action",	
	"btn_search"					=> "Rechercher",	
	"btn_clearsearch"				=> "Effacer la recherche",	
	"btn_download"					=> "Télécharger",	
	"btn_config"					=> "Configuration",	
	"btn_copy"						=> "Copier", // Ajax 
	"btn_print"						=> "Imprimer",	
	"btn_create"					=> "Creer",	
	"btn_install"					=> "Installer",
	"btn_backup"					=> "Backup",
	"btn_remove"					=> "Supprimer",
	"btn_edit"						=> "Modifier",	
	"btn_view"						=> "voir",
	"btn_typesearch"				=> "Taper & entrer",	// updated apidevlab	
	
/* Core Module */
	"t_menu"						=> "Géstion De Menu",
	"t_menusmall"					=> "Liste de tous les Menu",
	"t_tipsdrag"					=> "Glissez et déposez pour réorganiser la liste du menu", // updated apidevlab
	"t_tipsnote"					=> "Remarque !, Menus prennent uniquement en charge les 3 niveaux", // updated apidevlab
	"tab_topmenu"					=> "Menu du haut",
	"tab_sidemenu"					=> "Menu latéral ",
	"sb_reorder"					=> "Réorganiser le Menu",	
	"fr_mtitle"						=> "Nom / titre ",	
	"fr_mtype"						=> "Type De Menu ",	
	"fr_mposition"					=> "Position",	
	"fr_mactive"					=> "Active",	
	"fr_minactive"					=> "Inactive",
	"fr_maccess"					=> "Accès", // updated apidevlab	
	"fr_miconclass"					=> "Icon Class",
	"fr_mpublic"					=> "Public",
	"fr_mexample"					=> "Example",
	"fr_musage"						=> "Useage", // updated apidevlab	
	
/* Code BuilderModule */
	"t_module"						=> "Module",
	"t_modulesmall"					=> "Liste de tous les Modules",// updated apidevlab
	"tab_installed"					=> "Modules installés", // updated apidevlab
	"tab_core"						=> "Core Modules", // updated apidevlab
	"fr_modtitle"					=> "Module nom / titre",
	"fr_modnote"					=> "Module Note",
	"fr_modtable"					=> "Module Table",
	"fr_modautosql"					=> "Auto Mysql Statment",
	"fr_modmanualsql"				=> "Manual Mysql Statment ",
	"fr_createmodule"				=> "Créer nouveau Module",
	"fr_installmodule"				=> "Installer le Module",
	"fr_backupmodule"				=> "Sauvegarde et faire installeur pour modules ",

/* dashboard Interface */

	"dash_i_module"					=> "Module",
	"dash_i_setting"				=> "Réglage",
	"dash_i_sitemenu"				=> "Site Menu",
	"dash_i_usergroup"				=> "Utilisateur & Groupe",
	"dash_module"					=> "Gérer les Modules existants ou créer un nouveau",
	"dash_setting"					=> "Mise en place de votre option de connexion d’application, sitename, e-mail etc. ",
	"dash_sitemenu"					=> "Gérer le Menu de votre application frontend ou backend",
	"dash_usergroup"				=> "Gérer les utilisateurs et groupes et accorder ce module et le menu sont accesible",

/*updates	on may ,5 2014 */
	
	"loginsocial"				=> "Connexion via les réseaux sociaux", // updated apidevlab
	"enteremailforgot"			=> "Entrez votre adresse E-mail",
	"detail" 					=> "Afficher les détails",
	"addedit" 					=> "Ajouter - Modifier",
	
/* Notification */
	"note_noexists"				=> "Désolé, la Page n’existe pas !", // updated apidevlab
	"note_restric"				=> "Désolé, vous n'êtes pas autorisé à accéder à cette page !", // updated apidevlab
	"note_success"				=> "Enregistré avec succès !", // updated apidevlab
	"note_error"				=> "Les erreurs suivantes s’est produite !",
	"note_success_delete"		=> "Enlevé avec succès !",	// updated apidevlab
	"connect_stripe_note"		=> "Vous avez besoin pour vous connecter à striée tout d’abord.",
	"accept_payment"			=>"Membre n’est pas en mesure d’accepter le paiement dès maintenant.",
);