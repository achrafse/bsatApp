<?php

return array(

	"accepted"         => "Le :attribute doit être acceptée.",
	"active_url"       => "Le :attribute n’est pas une URL valide.",
	"after"            => "Le :attribute doit être une date postérieure à :date.",
	"alpha"            => "Le :attribute peut contenir uniquement des lettres.",
	"alpha_dash"       => "Le :attribute peut contenir uniquement des lettres, des chiffres et des tirets.",
	"alpha_num"        => "Le :attribute peut contenir uniquement des lettres et des chiffres.",
	"array"            => "Le :attribute doit être un tableau.",
	"before"           => "Le :attribute doit être une date avant :date.",
	"between"          => array(
		"numeric" => "Le :attribute doit être comprise entre :min et :max.",
		"file"    => "Le :attribute doit être comprise entre :min et :max kilo-octets.",
		"string"  => "Le :attribute doit être comprise entre :min et :max caractères.",
		"array"   => "Le :attribute doit avoir entre :min et :max éléments.",
	),
	"confirmed"        => "Le :attribute confirmation ne correspond pas .",
	"date"             => "Le :attribute n’est pas une date valide.",
	"date_format"      => "Le :attribute ne respecte pas Le format :format.",
	"different"        => "Le :attribute et :oLer doit être différent.",
	"digits"           => "Le :attribute doit être :digits chiffres.",
	"digits_between"   => "Le :attribute doit être comprise entre :min et :max chiffres.",
	"email"            => "Le :attribute format n’est pas valide.",
	"exists"           => "Le :attribute sélectionné n’est pas valide.",
	"image"            => "Le :attribute doit être une image.",
	"in"               => "Le :attribute sélectionné n’est pas valide.",
	"integer"          => "Le :attribute doit être un entier.",
	"ip"               => "Le :attribute doit être une adresse IP valide.",
	"max"              => array(
		"numeric" => "Le :attribute ne peut pas être supérieure à :max.",
		"file"    => "Le :attribute ne peut pas être supérieure à :max kilo-octets.",
		"string"  => "Le :attribute ne peut pas être supérieure à :max caractères.",
		"array"   => "Le :attribute ne peut pas être supérieure à :max éléments.",
	),
	"mimes"            => "Le :attribute doit être un fichier de type: :values.",
	"min"              => array(
		"numeric" => "Le :attribute doit être au moins :min.",
		"file"    => "Le :attribute doit être au moins :min kilo-octets.",
		"string"  => "Le :attribute doit être au moins :min caractères.",
		"array"   => "Le :attribute doit avoir au moins :min éléments.",
	),
	"not_in"           => "Le :attribute selectionné n’est pas valide.",
	"numeric"          => "Le :attribute doit être un nombre.",
	"regex"            => "Le :attribute format n’est pas valide.",
	"required"         => "Le :attribute champ est requis.",
	"required_if"      => "Le :attribute champ est requis quand :oLer est :value.",
	"required_with"    => "Le :attribute champ est requis quand :values est present.",
	"required_without" => "Le :attribute champ est requis quand :values n'est pas present.",
	"same"             => "Le :attribute et :oLer doit correspondre.",
	"size"             => array(
		"numeric" => "Le :attribute doit être :size.",
		"file"    => "Le :attribute doit être :size kilo-octets.",
		"string"  => "Le :attribute doit être :size caractères.",
		"array"   => "Le :attribute doit contenir :size éléments.",
	),
	"unique"           => "Le :attribute a déjà été pris.",
	"url"              => "Le :attribute format n’est pas valide.",
	"recaptcha" => 'Le :attribute champ n’est pas correct.',
	/*
	|--------------------------------------------------------------------------
	| Custom Validation Language Lines
	|--------------------------------------------------------------------------
	|
	| Here you may specify custom validation messages for attributes using Le
	| convention "attribute.rule" to name Le lines. This makes it quick to
	| specify a specific custom language line for a given attribute rule.
	|
	*/

	'custom' => array(),

	/*
	|--------------------------------------------------------------------------
	| Custom Validation Attributes
	|--------------------------------------------------------------------------
	|
	| Le following language lines are used to swap attribute place-holders
	| with something more reader friendly such as E-Mail Address instead
	| of "email". This simply helps us make messages a little cleaner.
	|
	*/

	'attributes' => array(),

);
